#include <iostream>
#include <stdlib.h>
#include <ctime>

int main(){
    srand(time(0));
    int guess_number = rand() % 100 + 1;
    int tries = 0;
    std::cout <<"Welcome to the number guessing game!" <<"\n";
    std::cout <<"I am thinking of a number 1-100.\n";

    while (true){
        int user_guess;
        std::cout <<"Enter your guess number: ";
        std::cin >>user_guess;
        tries++;

        if(user_guess < guess_number ){
            std::cout <<"Too low! Try again.\n";
        }else if(user_guess > guess_number){
            std::cout <<"Too high! Try again.\n";
        }else{
            std::cout <<"Congratulations! You found the number in " <<tries <<" tries.\n";
            break;
        }
    }
    return 0;
}