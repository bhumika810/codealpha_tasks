#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

string processInput(string input) {
    vector<string> tokens;
    string token;
    for (char c : input) {
        if (c == ' ') {
            tokens.push_back(token);
            token.clear();
        } else {
            token += c;
        }
    }
    tokens.push_back(token);

    int sentiment = 0;
    for (string token : tokens) {
        if (token == "good" || token == "great" || token == "excellent") {
            sentiment++;
        } else if (token == "bad" || token == "terrible" || token == "awful") {
            sentiment--;
        }
    }

    string response;
    if (sentiment > 0) {
        response = "I'm glad you're feeling positive!";
    } else if (sentiment < 0) {
        response = "Sorry to hear you're feeling negative.";
    } else {
        response = "I'm here to help. What's on your mind?";
    }

    return response;
}

int main() {
    string input;
    cout << "Welcome to the AI chatbot! Type 'quit' to exit.\n";
    while (true) {
        cout << "User: ";
        getline(cin, input);
        if (input == "quit") {
            break;
        }
        string response = processInput(input);
        cout << "Chatbot: " << response <<"\n";
    }
    return 0;
}
